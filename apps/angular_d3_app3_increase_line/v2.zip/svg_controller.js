var app = angular.module('myApp', []);
var holder;
var last_state;
app.controller('SVG_Ctrl', function($scope) {
    $scope.count = 2;
    var svgContainer = d3.select("body").append("svg")
        .attr("width", 200)
        .attr("height", 200);
    $scope.myFunction = function() {
var state="" + String($scope.height) + ",30,15,30";
        var circle = svgContainer.append("polyline")

        .attr("points", state)
		//.attr("points", "05,30,15,30")
            .attr("stroke", "blue")
            .attr("stroke-width", 2);
        $scope.count = $scope.height;



    }
});