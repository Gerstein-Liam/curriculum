var app = angular.module('myApp', []);
var holder;
var last_state;
var time_stamp;
app.controller('SVG_Ctrl', function($scope) {
    $scope.count = 2;
	time_stamp=0;
    var svgContainer = d3.select("body").append("svg")
        .attr("width", 400)
        .attr("height", 400);
    $scope.myFunction = function() {
	var state="" + String(time_stamp) + "," +String($scope.height*100)+ "," +String(time_stamp+30)+ "," +String($scope.height*100)+"";
	
	
	
	time_stamp=time_stamp+30;
	$scope.count=time_stamp;
	
	
	var circle = svgContainer.append("polyline")

        .attr("points", state)
		//.attr("points", "05,30,15,30")
            .attr("stroke", "blue")
            .attr("stroke-width", 2);
        $scope.count = $scope.height;



    }
});