var app = angular.module('myApp', []);
var holder;
	  
      app.controller('SVG_Ctrl', function($scope) {
		  var svgContainer = d3.select("body").append("svg")
                       .attr("width", 200)
                                    .attr("state", 200);
          $scope.count = 2;
          $scope.myFunction = function() {
              $scope.count=$scope.state;
       var circle = svgContainer.append("polyline")
                          
                        .attr("points","05,30,15,30")
                         .attr("stroke", "blue")
                          .attr("stroke-width", 2)  ;  
          }
      });